"""
支持 `python -m toyoko_tracker` 启动。
"""
from .app import main

if __name__ == "__main__":
    main()